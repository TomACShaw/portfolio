﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConfidantHelper
{
    internal class IwaiEvent : RankEvent
    {
        public IwaiEvent(int rank)
        {
            this.Rank = rank;
            this.NumChoices = this.getNumChoices(rank);
        }

        // Method to define the number of choices (dialogue options) based on what rank the event is.
        public int getNumChoices(int rank)
        {
            switch (rank)
            {
                case 0:
                    return 0;
                case 1:
                    return 0;
                case 2:
                    return 0;
                case 3:
                    return 0;
                case 4:
                    return 0;
                case 5:
                    return 0;
                case 6:
                    return 0;
                case 7:
                    return 0;
                case 8:
                    return 0;
                case 9:
                    return 0;
                default:
                    throw new ArgumentException("Invalid rank detected");

            }
        }

        // Main event running method
        public void runEvent(int rank)
        {
            switch (rank)
            {
                case 0:                                                                     // Rank 0, X choices
                    Console.WriteLine("bababooey");
                    return;


                case 1:                                                                     // Rank 1, X choices
                    Console.WriteLine("bubibaba");
                    return;


                case 2:                                                                     // Rank 2, X choices
                    Console.WriteLine("");
                    return;


                case 3:                                                                     // Rank 3, X choices
                    Console.WriteLine("");
                    return;


                case 4:                                                                     // Rank 4, X choices
                    Console.WriteLine("");
                    return;


                case 5:                                                                     // Rank 5, X choices
                    Console.WriteLine("");
                    return;


                case 6:                                                                     // Rank 6, X choices
                    Console.WriteLine("");
                    return;


                case 7:                                                                     // Rank 7, X choices
                    Console.WriteLine("");
                    return;


                case 8:                                                                     // Rank 8, X choices
                    Console.WriteLine("");
                    return;


                case 9:                                                                     // Rank 9, X choices
                    Console.WriteLine("");
                    return;


            }
        }
    }

}