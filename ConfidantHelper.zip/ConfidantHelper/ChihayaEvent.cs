﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConfidantHelper
{
    internal class ChihayaEvent : RankEvent
    {
        public ChihayaEvent(int rank)
        {
            this.Rank = rank;
            this.NumChoices = this.getNumChoices(rank);
        }

        // Method to define the number of choices (dialogue options) based on what rank the event is.
        public int getNumChoices(int rank)
        {
            switch (rank)
            {
                case 0:
                    return 6;
                case 1:
                    return 4;
                case 2:
                    return 3;
                case 3:
                    return 6;
                case 4:
                    return 3;
                case 5:
                    return 5;
                case 6:
                    return 2;
                case 7:
                    return 4;
                case 8:
                    return 3;
                case 9:
                    return 7;
                default:
                    throw new ArgumentException("Invalid rank detected");

            }
        }

        // Main event running method
        public void runEvent(int rank)
        {
            switch (rank)
            {
                case 0:                                                                     // Rank 0, 6 choices
                    Console.WriteLine("1. IC (Fate is not absolute.)");
                    Console.WriteLine("2. IC (I didn't make any deals.)");
                    Console.WriteLine("3. IC (I'm just an ordiary student.)");
                    Console.WriteLine("4. IC (I'm too busy for that.)");
                    Console.WriteLine("5. IC (All right, I guess.)");
                    Console.WriteLine("6. I'll be there.");
                    return;


                case 1:                                                                     // Rank 1, 4 choices
                    Console.WriteLine("1. Change her boss's heart.");
                    Console.WriteLine("2. Overturn your fate!");
                    Console.WriteLine("3. Open your mind to change.");
                    Console.WriteLine("4. Of course I am.");
                    return;


                case 2:                                                                     // Rank 2, 3 choices
                    Console.WriteLine("1. Follow his heart.");
                    Console.WriteLine("2. Thieves may steal her away.");
                    Console.WriteLine("3. IC (I'm not, sorry.)");
                    return;


                case 3:                                                                     // Rank 3, 6 choices
                    Console.WriteLine("1. IC(You're only realizing that now?)");
                    Console.WriteLine("2. Trust in yourself.");
                    Console.WriteLine("3. IC (Tell me more.)");
                    Console.WriteLine("4. IC (...The chairman?)");
                    Console.WriteLine("5. IC (I think it'll work.)");
                    Console.WriteLine("6. I didn't do much.");
                    return;


                case 4:                                                                     // Rank 4, 3 choices
                    Console.WriteLine("1. You're such a hard worker.");
                    Console.WriteLine("2. IC (But what?)");
                    Console.WriteLine("3. IC (Who was he?)");
                    return;


                case 5:                                                                     // Rank 5, 5 choices
                    Console.WriteLine("1. IC (I like fortune telling.)");
                    Console.WriteLine("2. IC (...Maiden of Relief?)");
                    Console.WriteLine("3. IC (This guy's sketchy.)");
                    Console.WriteLine("4. You're just Chihaya to me.");
                    Console.WriteLine("5. Be honest with yourself.");
                    return;


                case 6:                                                                     // Rank 6, 2 choices
                    Console.WriteLine("1. I don't think so.");
                    Console.WriteLine("2. Are you gonna be okay?");
                    return;


                case 7:                                                                     // Rank 7, 4 choices
                    Console.WriteLine("I know.");
                    Console.WriteLine("2. IC (I'm glad to hear that.)");
                    Console.WriteLine("3. Hell yeah I am.");
                    Console.WriteLine("4. It was all your own will.");
                    return;


                case 8:                                                                     // Rank 8, 3 choices
                    Console.WriteLine("1. IC (You really don't understand.)");
                    Console.WriteLine("2. Well, fate can be changed.");
                    Console.WriteLine("3. So I can be with you. -> Romance, I like having my fortune read. -> Friendship");
                    return;


                case 9:                                                                     // Rank 9, 7 choices
                    Console.WriteLine("1. IC (You've never been here?)");
                    Console.WriteLine("2. IC (I support you.)");
                    Console.WriteLine("3. IC (I wonder if you're right...)");
                    Console.WriteLine("4. IC (It's not a problem.)");
                    Console.WriteLine("5. IC (Thank you, Chihaya.)");
                    Console.WriteLine("6. It's actually pretty cute.");
                    Console.WriteLine("7. IC (I was hoping you'd say that.)");
                    return;
            }
        }
    }

}