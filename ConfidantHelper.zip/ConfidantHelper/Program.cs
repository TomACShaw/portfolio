﻿using System;

namespace ConfidantHelper;

internal class Program
{
    private static void Main(string[] args)
    {

        // Declare variables
        string confidantName = string.Empty;
        string confidantArcana = string.Empty;
        string userInput = string.Empty;
        int rank;


        // Create confidants dictionary
        Dictionary<string, string> NameKeyConfidants = new Dictionary<string, string>
        {
            { "ryuji", "chariot" },
            { "takemi", "death" },
            { "ohya" , "devil" },
            { "yusuke" , "emperor" },
            { "haru" , "empress" },
            { "chihaya" , "fortune" },
            { "iwai" , "hanged" },
            { "futaba" , "hermit" },
            { "sojiro" , "hierophant" },
            { "akechi" , "justice" },
            { "ann" , "lovers" },
            { "makoto" , "priestess" },
            { "hifumi" , "star" },
            { "yoshida" , "sun" },
            { "kawakami" , "temperance" },
            { "shinya" , "tower" },
            { "kasumi" , "faith" },
            { "maruki" , "councillor" }
            };

        // Create a reverse dictionary for easy lookup by name or key
        Dictionary<string, string> ArcanaKeyConfidants = NameKeyConfidants.ToDictionary(kvp => kvp.Value, kvp => kvp.Key);


        Console.Clear();
        Console.WriteLine("Welcome to the Confidant Helper.");


        // Get and validate confidant name
        
        // if the user's input is a name, return the input as confidantName and set the corresponding confidantArcana.
        // if the input is the arcana instead, return it as the confidantArcana and set the corresponding name.
        // else, the user entered invalid input.
        // Repeat this process until the input matches either the name or arcana correctly.
        while (!NameKeyConfidants.ContainsKey(userInput) && !ArcanaKeyConfidants.ContainsKey(userInput))
        {
            Console.WriteLine("Which Confidant are you spending time with?");
            userInput = Console.ReadLine().ToLower();
            Console.WriteLine();


            if (NameKeyConfidants.ContainsKey(userInput))
            {
                // Make the confidant name title case for consistency
                confidantArcana = NameKeyConfidants[userInput];
                confidantArcana = (confidantArcana.Substring(0, 1).ToUpper()) + confidantArcana.Substring(1);
                confidantName = (userInput.Substring(0, 1).ToUpper()) + userInput.Substring(1);
            }
            else if (ArcanaKeyConfidants.ContainsKey(userInput))
            {
                confidantName = ArcanaKeyConfidants[userInput];
                confidantName = (confidantName.Substring(0, 1).ToUpper()) + confidantName.Substring(1);
                confidantArcana = (userInput.Substring(0, 1).ToUpper()) + userInput.Substring(1);
            }
            else
            {
                Console.WriteLine("Confidant not found. Please check your input and try again.");
                Console.WriteLine();
            }
        }

        Console.WriteLine($"You're hanging out with {confidantName}, the {confidantArcana} Arcana.");
        Console.WriteLine();


        // Get and validate rank
        Console.WriteLine("What is the current rank of your Confidant? (0-9)");
        userInput = Console.ReadLine();
        Console.WriteLine();

        while (!int.TryParse(userInput, out rank) || rank < 0 || rank > 9)
        {
            
            Console.WriteLine("Invalid rank. Please enter a number between 0 and 9.");
            Console.WriteLine();

            Console.WriteLine("What is the current rank of your Confidant? (0-9)");
            userInput = Console.ReadLine();
            Console.WriteLine();
        }

        Console.WriteLine($"Fetching dialogue for {confidantName} at rank {rank}. Press any key to continue.");
        Console.ReadKey();
        Console.Clear();


        // Switch statement
        switch (confidantName)
        {
            case "Ryuji":
                RyujiEvent ryujiEvent = new RyujiEvent(rank);
                ryujiEvent.NumChoices = ryujiEvent.getNumChoices(rank);
                ryujiEvent.beginEvent();
                ryujiEvent.runEvent(rank);
                break;          // Done
            case "Takemi":
                TakemiEvent takemiEvent = new TakemiEvent(rank);
                takemiEvent.NumChoices = takemiEvent.getNumChoices(rank);
                takemiEvent.beginEvent();
                takemiEvent.runEvent(rank);
                return;         // Done
            case "Ohya":
                OhyaEvent ohyaEvent = new OhyaEvent(rank);
                ohyaEvent.NumChoices = ohyaEvent.getNumChoices(rank);
                ohyaEvent.beginEvent();
                ohyaEvent.runEvent(rank);
                return;           // Done
            case "Yusuke":
                YusukeEvent yusukeEvent = new YusukeEvent(rank);
                yusukeEvent.NumChoices = yusukeEvent.getNumChoices(rank);
                yusukeEvent.beginEvent();
                yusukeEvent.runEvent(rank);
                return;         // Done
            case "Haru":
                HaruEvent haruEvent = new HaruEvent(rank);
                haruEvent.NumChoices = haruEvent.getNumChoices(rank);
                haruEvent.beginEvent();
                haruEvent.runEvent(rank);
                return;           // Done
            case "Chihaya":
                ChihayaEvent chihayaEvent = new ChihayaEvent(rank);
                chihayaEvent.NumChoices = chihayaEvent.getNumChoices(rank);
                chihayaEvent.beginEvent();
                chihayaEvent.runEvent(rank);
                return;           // Done
            case "Iwai":
                IwaiEvent iwaiEvent = new IwaiEvent(rank);
                iwaiEvent.NumChoices = iwaiEvent.getNumChoices(rank);
                iwaiEvent.beginEvent();
                iwaiEvent.runEvent(rank);
                return;
            case "Futaba":
                FutabaEvent futabaEvent = new FutabaEvent(rank);
                futabaEvent.NumChoices = futabaEvent.getNumChoices(rank);
                futabaEvent.beginEvent();
                futabaEvent.runEvent(rank);
                return;
            case "Sojiro":
                SojiroEvent sojiroEvent = new SojiroEvent(rank);
                sojiroEvent.NumChoices = sojiroEvent.getNumChoices(rank);
                sojiroEvent.beginEvent();
                sojiroEvent.runEvent(rank);
                return;
            case "Akechi":
                AkechiEvent akechiEvent = new AkechiEvent(rank);
                akechiEvent.NumChoices = akechiEvent.getNumChoices(rank);
                akechiEvent.beginEvent();
                akechiEvent.runEvent(rank);
                return;
            case "Ann":
                AnnEvent annEvent = new AnnEvent(rank);
                annEvent.NumChoices = annEvent.getNumChoices(rank);
                annEvent.beginEvent();
                annEvent.runEvent(rank);
                return;
            case "Makoto":
                MakotoEvent makotoEvent = new MakotoEvent(rank);
                makotoEvent.NumChoices = makotoEvent.getNumChoices(rank);
                makotoEvent.beginEvent();
                makotoEvent.runEvent(rank);
                return;
            case "Hifumi":
                HifumiEvent hifumiEvent = new HifumiEvent(rank);
                hifumiEvent.NumChoices = hifumiEvent.getNumChoices(rank);
                hifumiEvent.beginEvent();
                hifumiEvent.runEvent(rank);
                return;
            case "Yoshida":
                YoshidaEvent yoshidaEvent = new YoshidaEvent(rank);
                yoshidaEvent.NumChoices = yoshidaEvent.getNumChoices(rank);
                yoshidaEvent.beginEvent();
                yoshidaEvent.runEvent(rank);
                return;
            case "Kawakami":
                KawakamiEvent kawakamiEvent = new KawakamiEvent(rank);
                kawakamiEvent.NumChoices = kawakamiEvent.getNumChoices(rank);
                kawakamiEvent.beginEvent();
                kawakamiEvent.runEvent(rank);
                return;
            case "Shinya":
                ShinyaEvent shinyaEvent = new ShinyaEvent(rank);
                shinyaEvent.NumChoices = shinyaEvent.getNumChoices(rank);
                shinyaEvent.beginEvent();
                shinyaEvent.runEvent(rank);
                return;
            case "Kasumi":
                KasumiEvent kasumiEvent = new KasumiEvent(rank);
                kasumiEvent.NumChoices = kasumiEvent.getNumChoices(rank);
                kasumiEvent.beginEvent();
                kasumiEvent.runEvent(rank);
                return;
            case "Maruki":
                MarukiEvent marukiEvent = new MarukiEvent(rank);
                marukiEvent.NumChoices = marukiEvent.getNumChoices(rank);
                marukiEvent.beginEvent();
                marukiEvent.runEvent(rank);
                return;
        }

        Console.WriteLine();
        Console.WriteLine("Thank you for using the Confidant Helper!");

    }
}