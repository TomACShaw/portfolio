﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConfidantHelper
{
    internal class RyujiEvent : RankEvent
    {
        public RyujiEvent(int rank)
        {
            this.Rank = rank;
            this.NumChoices = this.getNumChoices(rank);
        }


        // Method to define the number of choices (dialogue options) based on what rank the event is.
        public int getNumChoices(int rank)
        {
            switch (rank)
            {
                case 0:
                    return 6;
                case 1:
                    return 4;
                case 2:
                    return 3;
                case 3:
                    return 2;
                case 4:
                    return 4;
                case 5:
                    return 6;
                case 6:
                    return 3;
                case 7:
                    return 5;
                case 8:
                    return 5;
                case 9:
                    return 2;
                default:
                    throw new ArgumentException("Invalid rank detected");

            }
        }

        // Main event running method
        public void runEvent(int rank)
        {
            switch (rank)
            {
                case 0:
                    Console.WriteLine("No choices are relevant for this ranking event.");   // Rank 0, 6 choices (irrelevant)
                    return;


                case 1:                                                                     // Rank 1, 4 choices
                    Console.WriteLine("1. I'm counting on you.");
                    Console.WriteLine("2. IC (What about them?)");
                    Console.WriteLine("3. Do you want to go back?");
                    Console.WriteLine("4. You're already fast enough.");
                    return;


                case 2:                                                                     // Rank 2, 3 choices
                    Console.WriteLine("1. Let's not fight.");
                    Console.WriteLine("2. Calm down, Ryuji.");
                    Console.WriteLine("3. I can't exactly blame you.");
                    return;


                case 3:                                                                     // Rank 3, 2 choices
                    Console.WriteLine("1. Are you worried about him?");
                    Console.WriteLine("2. But you're doing great.");
                    return;


                case 4:                                                                     // Rank 4, 4 choices
                    Console.WriteLine("1. Protein powder?");
                    Console.WriteLine("2. You seem conflicted.");
                    Console.WriteLine("3. So he's an asshole?");
                    Console.WriteLine("4. Don't worry. I gotcha.");
                    return;


                case 5:                                                                     // Rank 5, 6 choices
                    Console.WriteLine("1. We can train at my place.");
                    Console.WriteLine("2. You guys should trust Nakaoka.");
                    Console.WriteLine("3. Absolutely.");
                    Console.WriteLine("4. IC (I don't get it.)");
                    Console.WriteLine("5. IC (...Huh?)");
                    Console.WriteLine("6. So he should've punched back?");
                    return;


                case 6:                                                                     // Rank 6, 3 choices
                    Console.WriteLine("1. Let's talk to Takeishi.");
                    Console.WriteLine("2. I think it's cool, Ryuji.");
                    Console.WriteLine("3. Never know until you try.");
                    return;


                case 7:                                                                     // Rank 7, 5 choices
                    Console.WriteLine("1. IC (What if they start fighting?)");
                    Console.WriteLine("2. IC (Things turned out for the best.)");
                    Console.WriteLine("3. All I did was watch.");
                    Console.WriteLine("4. You weren't cool though.");
                    Console.WriteLine("5. So. Case closed?");
                    return;


                case 8:                                                                     // Rank 8, 5 choices
                    Console.WriteLine("1. Are you satisfied now?");
                    Console.WriteLine("2. Don't do it.");
                    Console.WriteLine("3. I never realized that.");
                    Console.WriteLine("4. I agree.");
                    Console.WriteLine("5. Congratulations.");
                    return;


                case 9:                                                                     // Rank 9, 2 choices
                    Console.WriteLine("1. IC (I'm looking forward to it.)");
                    Console.WriteLine("3. IC (You're welcome.)");
                    return;


            }
        }
    }
}
