﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConfidantHelper
{
    internal class OhyaEvent : RankEvent
    {
        public OhyaEvent(int rank)
        {
            this.Rank = rank;
            this.NumChoices = this.getNumChoices(rank);
        }

        // Method to define the number of choices (dialogue options) based on what rank the event is.
        public int getNumChoices(int rank)
        {
            switch (rank)
            {
                case 0:
                    return 4;
                case 1:
                    return 3;
                case 2:
                    return 4;
                case 3:
                    return 4;
                case 4:
                    return 5;
                case 5:
                    return 5;
                case 6:
                    return 4;
                case 7:
                    return 5;
                case 8:
                    return 6;
                case 9:
                    return 4;
                default:
                    throw new ArgumentException("Invalid rank detected");

            }
        }

        // Main event running method
        public void runEvent(int rank)
        {
            switch (rank)
            {
                case 0:                                                                     // Rank 0, 4 choices
                    Console.WriteLine("No choices are relevant for this ranking event.");
                    return;


                case 1:                                                                     // Rank 1, 3 choices
                    Console.WriteLine("1. Mishima might...");
                    Console.WriteLine("2. IC (Worth... ?");
                    Console.WriteLine("3. It's for the article.");
                    return;


                case 2:                                                                     // Rank 2, 4 choices
                    Console.WriteLine("1. You shouldn't make assumptions.");
                    Console.WriteLine("2. IC (What's the difference?)");
                    Console.WriteLine("3. IC (Why not change careers?");
                    Console.WriteLine("4. She was falsely accused?");
                    return;


                case 3:                                                                     // Rank 3, 4 choices
                    Console.WriteLine("1. IC (What's this about?)");
                    Console.WriteLine("2. IC (Of course we are.)");
                    Console.WriteLine("3. IC (Our move is about to start.)");
                    Console.WriteLine("4. Leave it to me.");
                    return;


                case 4:                                                                     // Rank 4, 5 choices
                    Console.WriteLine("1. IC (Because of your investigation?)");
                    Console.WriteLine("2. IC (I'm curious.)");
                    Console.WriteLine("3. IC (What was the cause of death?)");
                    Console.WriteLine("4. That's unforgivable.");
                    Console.WriteLine("5. I don't mind it.");
                    return;


                case 5:                                                                     // Rank 5, 5 choices
                    Console.WriteLine("1. IC (Did something bad happen?)");
                    Console.WriteLine("2. He must not like you.");
                    Console.WriteLine("3. You should trust in her.");
                    Console.WriteLine("4. That's the spirit.");
                    Console.WriteLine("5. I'll dig up some more for you.");
                    return;


                case 6:                                                                     // Rank 6, 4 choices
                    Console.WriteLine("1. IC (What was that about?)");
                    Console.WriteLine("2. Don't let him provoke you.");
                    Console.WriteLine("3. You're charming as you are.");
                    Console.WriteLine("4. That's the spirit.");
                    return;


                case 7:                                                                     // Rank 7, 5 choices
                    Console.WriteLine("1. IC (He reflected on his actions.)");
                    Console.WriteLine("2. IC (Did I? Can't remember.)");
                    Console.WriteLine("3. IC (I'm glad to hear that.)");
                    Console.WriteLine("4. IC (I'll go with you. -> Romance)");
                    Console.WriteLine("5. Good luck.");
                    return;


                case 8:                                                                     // Rank 8, 6 choices
                    Console.WriteLine("1. IC (Are you okay?)");
                    Console.WriteLine("2. You're not giving up, are you?");
                    Console.WriteLine("3. I can't leave you.");
                    Console.WriteLine("4. IC (Of couse not.)");
                    Console.WriteLine("5. I took it seriously. -> Romance, I didn't take it seriously. -> Friendship");
                    Console.WriteLine("6. I love you, Ichiko. -> Romance, I'm just kidding. -> Friendship");
                    return;


                case 9:                                                                     // Rank 9, 4 choices
                    Console.WriteLine("1. Is that entertainment?");
                    Console.WriteLine("2. IC (I'm glad to hear that.)");
                    Console.WriteLine("3. IC (So you knew all along?)");
                    Console.WriteLine("4. I want to go to your place.");
                    return;


            }
        }
    }

}