﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConfidantHelper

{
    internal class RankEvent
    {
        /* * Represents an event related to a confidant's rank.
         * Fields:
         *      confidantName: The name of the confidant
         *      rank: The current rank of the confidant
         *      numChoices: the number of dialogue choices
         *      numChoices array?: an array with 10 values of the number of choices for each event, 0-9?
         */


        private int rank;
        private int numChoices;
        public int Rank { get { return rank; } set { rank = value; } }
        public int NumChoices { get { return numChoices; } set { numChoices = value; } }



        public void beginEvent()
        {
            Console.WriteLine($"Beginning event at rank {this.Rank}.");
            Console.WriteLine($"This event has {this.NumChoices} dialogue choices.");
            Console.WriteLine();
            Console.WriteLine("The following dialogue choices provide the maximum number of available music notes (affinity) for this event.");
            Console.WriteLine("If a choice begins with 'IC', it is an irrelevant choice - ");
            Console.WriteLine("none of the choices will give any music notes.");
            Console.WriteLine();
            //Console.WriteLine("Press any key to continue to the next dialogue option.");
            //Console.WriteLine();
            //Console.ReadKey(true);
            return;
        }


    }
}
