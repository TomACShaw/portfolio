﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConfidantHelper
{
    internal class YusukeEvent : RankEvent
    {
        public YusukeEvent(int rank)
        {
            this.Rank = rank;
            this.NumChoices = this.getNumChoices(rank);
        }

        // Method to define the number of choices (dialogue options) based on what rank the event is.
        public int getNumChoices(int rank)
        {
            switch (rank)
            {
                case 0:
                    return 1;
                case 1:
                    return 3;
                case 2:
                    return 5;
                case 3:
                    return 3;
                case 4:
                    return 3;
                case 5:
                    return 5;
                case 6:
                    return 3;
                case 7:
                    return 2;
                case 8:
                    return 2;
                case 9:
                    return 5;
                default:
                    throw new ArgumentException("Invalid rank detected");

            }
        }

        // Main event running method
        public void runEvent(int rank)
        {
            switch (rank)
            {
                case 0:                                                                     // Rank 0, 1 choices
                    Console.WriteLine("No choices are relevant for this ranking event.");
                    return;


                case 1:                                                                     // Rank 1, 3 choices
                    Console.WriteLine("1. It's novel.");
                    Console.WriteLine("2. I can't wait.");
                    Console.WriteLine("3. You're already doing enough.");
                    return;


                case 2:                                                                     // Rank 2, 5 choices
                    Console.WriteLine("1. Don't let it bother you.");
                    Console.WriteLine("2. IC (Stop exaggerating.)");
                    Console.WriteLine("3. This isn't like you.");
                    Console.WriteLine("4. IC (How exactly?)");
                    Console.WriteLine("5. That's the spirit.");
                    return;


                case 3:                                                                     // Rank 3, 3 choices
                    Console.WriteLine("1. Why are we in a boat?");
                    Console.WriteLine("2. Love comes in all forms.");
                    Console.WriteLine("3. Don't get discouraged.");
                    return;


                case 4:                                                                     // Rank 4, 3 choices
                    Console.WriteLine("1. Do you want me to strip?");
                    Console.WriteLine("2. I'm sure you will.");
                    Console.WriteLine("3. There's still hope.");
                    return;


                case 5:                                                                     // Rank 5, 5 choices
                    Console.WriteLine("1. It feels nostalgic.");
                    Console.WriteLine("2. IC (We should get it fixed.)");
                    Console.WriteLine("3. IC (Are you OK?)");
                    Console.WriteLine("4. Maybe he was sympathetic.");
                    Console.WriteLine("5. He had a certain dignity.");
                    return;


                case 6:                                                                     // Rank 6, 3 choices
                    Console.WriteLine("1. What do you mean?");
                    Console.WriteLine("2. The truth is within you.");
                    Console.WriteLine("3. Calm down.");
                    return;


                case 7:                                                                     // Rank 7, 2 choices
                    Console.WriteLine("1. It has to be Ann.");
                    Console.WriteLine("2. You've really grown, Yusuke.");
                    return;


                case 8:                                                                     // Rank 8, 2 choices
                    Console.WriteLine("1. Her love for her son.");
                    Console.WriteLine("2. You've really changed, Yusuke.");
                    return;


                case 9:                                                                     // Rank 9, 5 choices
                    Console.WriteLine("No choices are relevant for this ranking event.");
                    return;


            }
        }
    }

}