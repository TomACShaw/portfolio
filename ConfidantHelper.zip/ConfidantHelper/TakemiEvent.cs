﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConfidantHelper
{
    internal class TakemiEvent : RankEvent
    {
        public TakemiEvent(int rank)
        {
            this.Rank = rank;
            this.NumChoices = this.getNumChoices(rank);
        }

        // Method to define the number of choices (dialogue options) based on what rank the event is.
        public int getNumChoices(int rank)
        {
            switch (rank)
            {
                case 0:
                    return 8;
                case 1:
                    return 3;
                case 2:
                    return 4;
                case 3:
                    return 3;
                case 4:
                    return 4;
                case 5:
                    return 4;
                case 6:
                    return 4;
                case 7:
                    return 4;
                case 8:
                    return 7;
                case 9:
                    return 3;
                default:
                    throw new ArgumentException("Invalid rank detected");

            }
        }

        // Main event running method
        public void runEvent(int rank)
        {
            switch (rank)
            {
                case 0:                                                                     // Rank 0, 8 choices
                    Console.WriteLine("1. IC (It's for brainpower.)");
                    Console.WriteLine("2. IC (I need that medicine.");
                    Console.WriteLine("3. IC (I'm not leaving.)");
                    Console.WriteLine("4. IC (What would I be doing?)");
                    Console.WriteLine("5. IC (Don't mind if I do.)");
                    Console.WriteLine("6. IC (I'm not outta my mind.)");
                    Console.WriteLine("7. IC (Of course.)");
                    Console.WriteLine("8. Please go easy on me.");
                    return;


                case 1:                                                                     // Rank 1, 3 choices
                    Console.WriteLine("1. I have a bad heart.");
                    Console.WriteLine("2. I agree.");
                    Console.WriteLine("3. I'm totally fine.");
                    return;


                case 2:                                                                     // Rank 2, 4 choices
                    Console.WriteLine("1. IC (What was that about?)");
                    Console.WriteLine("2. IC (A medical error?)");
                    Console.WriteLine("3. I don't mind.");
                    Console.WriteLine("4. Of course not.");
                    return;


                case 3:                                                                     // Rank 3, 3 choices
                    Console.WriteLine("1. Dr. Takemi will help.");
                    Console.WriteLine("2. You seem happy.");
                    Console.WriteLine("3. I'll reflect on my mistakes.");
                    return;


                case 4:                                                                     // Rank 4, 4 choices
                    Console.WriteLine("1. IC (They trust you.)");
                    Console.WriteLine("2. IC (I had no idea.)");
                    Console.WriteLine("3. That's good.");
                    Console.WriteLine("4. About Miwa-chan?");
                    return;


                case 5:                                                                     // Rank 5, 4 choices
                    Console.WriteLine("1. IC (Well, someone's popular.)");
                    Console.WriteLine("2. IC (Having fun?)");
                    Console.WriteLine("3. It suits you.");
                    Console.WriteLine("4. You can count on me.");
                    return;


                case 6:                                                                     // Rank 6, 4 choices
                    Console.WriteLine("1. IC (This is harassment.)");
                    Console.WriteLine("2. IC (Don't lose hope.)");
                    Console.WriteLine("3. Just rest for today.");
                    Console.WriteLine("4. We all do sometimes.");
                    return;


                case 7:                                                                     // Rank 7, 4 choices
                    Console.WriteLine("1. IC (Miwa-chan is alive.)");
                    Console.WriteLine("2. Let's get to work, doctor.");
                    Console.WriteLine("3. It's for Miwa-chan.");
                    Console.WriteLine("4. I'll be cheering you on.");
                    return;


                case 8:                                                                     // Rank 8, 7 choices
                    Console.WriteLine("1. It was rough.");
                    Console.WriteLine("2. IC (That's troubling.)");
                    Console.WriteLine("3. OPTION: I wanted to see you. -> Romance. It was for my exams. -> Friendship");
                    Console.WriteLine("4. OPTION: I love you. -> Romance. What do you think? -> Friendship");
                    Console.WriteLine("5. OPTION: It isn't a joke. -> Romance. That sounds good. -> Friendship");
                    Console.WriteLine("6. So did you.");
                    Console.WriteLine("7. I'm glad we saw it through.");
                    return;


                case 9:                                                                     // Rank 9, 3 choices
                    Console.WriteLine("1. IC (Uh, what?)");
                    Console.WriteLine("2. 2. I wonder...");
                    Console.WriteLine("3. Yes, please. (Romance)");
                    return;


            }
        }
    }

}