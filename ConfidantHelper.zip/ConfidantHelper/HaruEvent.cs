﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConfidantHelper
{
    internal class HaruEvent : RankEvent
    {
        public HaruEvent(int rank)
        {
            this.Rank = rank;
            this.NumChoices = this.getNumChoices(rank);
        }

        // Method to define the number of choices (dialogue options) based on what rank the event is.
        public int getNumChoices(int rank)
        {
            switch (rank)
            {
                case 0:
                    return 1;
                case 1:
                    return 4;
                case 2:
                    return 4;
                case 3:
                    return 6;
                case 4:
                    return 4;
                case 5:
                    return 6;
                case 6:
                    return 5;
                case 7:
                    return 4;
                case 8:
                    return 5;
                case 9:
                    return 4;
                default:
                    throw new ArgumentException("Invalid rank detected");

            }
        }

        // Main event running method
        public void runEvent(int rank)
        {
            switch (rank)
            {
                case 0:                                                                     // Rank 0, 1 choices
                    Console.WriteLine("1. That was our deal.");
                    return;


                case 1:                                                                     // Rank 1, 4 choices
                    Console.WriteLine("1. IC (You like coffee?");
                    Console.WriteLine("2. He sounds suspicious.");
                    Console.WriteLine("3. IC (This is a complex issue.)");
                    Console.WriteLine("4. IC (Moonlight Carrot.)");
                    return;


                case 2:                                                                     // Rank 2, 4 choices
                    Console.WriteLine("1. They won't find out.");
                    Console.WriteLine("2. I don't want to go with you.");
                    Console.WriteLine("3. IC (I have.)");
                    Console.WriteLine("4. Smart response.");
                    return;


                case 3:                                                                     // Rank 3, 6 choices
                    Console.WriteLine("1. That's pricey.");
                    Console.WriteLine("2. IC (I can't let you do that.)");
                    Console.WriteLine("3. IC (You mean... poop!?)");
                    Console.WriteLine("4. Let's ask him.");
                    Console.WriteLine("5. I'm not really sure.");
                    Console.WriteLine("6. Let's get coffee again sometime.");
                    return;


                case 4:                                                                     // Rank 4, 4 choices
                    Console.WriteLine("1. Somebody's telling the truth.");
                    Console.WriteLine("2. There has to be another way.");
                    Console.WriteLine("3. I don't think so.");
                    Console.WriteLine("4. Pinch yourself.");
                    return;


                case 5:                                                                     // Rank 5, 6 choices
                    Console.WriteLine("1. IC (That's fascinating.)");
                    Console.WriteLine("2. I had no idea.");
                    Console.WriteLine("3. That would be bad.");
                    Console.WriteLine("4. IC (You don't need to apologize.");
                    Console.WriteLine("5. Be strong, Haru.");
                    Console.WriteLine("6. You can talk to me anytime.");
                    return;


                case 6:                                                                     // Rank 6, 5 choices
                    Console.WriteLine("1. IC (You look exhausted.)");
                    Console.WriteLine("2. That sounds really tough...");
                    Console.WriteLine("3. IC (What does Takakura-san think?)");
                    Console.WriteLine("4. IC (That's the spirit.)");
                    Console.WriteLine("5. I'll always have your back.");
                    return;


                case 7:                                                                     // Rank 7, 4 choices
                    Console.WriteLine("1. The soil?");
                    Console.WriteLine("2. IC (It'll help him understand you.)");
                    Console.WriteLine("3. IC (I'll be cheering for you.)");
                    Console.WriteLine("4. It's in your nature to nurture.");
                    return;


                case 8:                                                                     // Rank 8, 5 choices
                    Console.WriteLine("1. IC (Don't forget to breathe.)");
                    Console.WriteLine("2. IC (I'm sure you'll do great.)");
                    Console.WriteLine("3. You're very welcome.");
                    Console.WriteLine("4. IC (OPTION: I like you too, Haru. -> Romance)");
                    Console.WriteLine("5. I wanted to hear your voice.");
                    return;


                case 9:                                                                     // Rank 9, 4 choices
                    Console.WriteLine("1. That's good to hear.");
                    Console.WriteLine("2. IC (I'm sure you'll succeed.)");
                    Console.WriteLine("3. IC (If you want.)");
                    Console.WriteLine("4. IC (I'm glad too.)");
                    return;


            }
        }
    }

}