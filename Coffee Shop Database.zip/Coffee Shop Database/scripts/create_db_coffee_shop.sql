-- MySQL Workbench Forward Engineering

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION';

-- -----------------------------------------------------
-- Schema coffee_shop
-- -----------------------------------------------------
DROP SCHEMA IF EXISTS `coffee_shop` ;

-- -----------------------------------------------------
-- Schema coffee_shop
-- -----------------------------------------------------
CREATE SCHEMA IF NOT EXISTS `coffee_shop` DEFAULT CHARACTER SET utf8mb3 ;
USE `coffee_shop` ;

-- -----------------------------------------------------
-- Table `coffee_shop`.`customers`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `coffee_shop`.`customers` ;

CREATE TABLE IF NOT EXISTS `coffee_shop`.`customers` (
  `customer_id` INT NOT NULL AUTO_INCREMENT,
  `name` VARCHAR(50) NOT NULL,
  `phone` CHAR(10) NOT NULL,
  `email` VARCHAR(100) NOT NULL,
  PRIMARY KEY (`customer_id`),
  UNIQUE INDEX `customer_id_UNIQUE` (`customer_id` ASC) VISIBLE)
ENGINE = InnoDB
AUTO_INCREMENT = 31
DEFAULT CHARACTER SET = utf8mb3;


-- -----------------------------------------------------
-- Table `coffee_shop`.`suppliers`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `coffee_shop`.`suppliers` ;

CREATE TABLE IF NOT EXISTS `coffee_shop`.`suppliers` (
  `supplier_id` INT NOT NULL AUTO_INCREMENT,
  `name` VARCHAR(50) NOT NULL,
  `address` VARCHAR(255) NOT NULL,
  `email` VARCHAR(100) NOT NULL,
  PRIMARY KEY (`supplier_id`),
  UNIQUE INDEX `supplier_id_UNIQUE` (`supplier_id` ASC) VISIBLE)
ENGINE = InnoDB
AUTO_INCREMENT = 6
DEFAULT CHARACTER SET = utf8mb3;


-- -----------------------------------------------------
-- Table `coffee_shop`.`ingredients`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `coffee_shop`.`ingredients` ;

CREATE TABLE IF NOT EXISTS `coffee_shop`.`ingredients` (
  `ingredient_id` INT NOT NULL AUTO_INCREMENT,
  `name` VARCHAR(50) NOT NULL,
  `serving_size_floz` FLOAT NOT NULL,
  `calories_per_serving` INT NOT NULL,
  `supplier_id` INT NOT NULL,
  PRIMARY KEY (`ingredient_id`),
  UNIQUE INDEX `ingredient_id_UNIQUE` (`ingredient_id` ASC) VISIBLE,
  INDEX `supplier_id_idx` (`supplier_id` ASC) VISIBLE,
  CONSTRAINT `supplier_id`
    FOREIGN KEY (`supplier_id`)
    REFERENCES `coffee_shop`.`suppliers` (`supplier_id`))
ENGINE = InnoDB
AUTO_INCREMENT = 7
DEFAULT CHARACTER SET = utf8mb3;


-- -----------------------------------------------------
-- Table `coffee_shop`.`products`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `coffee_shop`.`products` ;

CREATE TABLE IF NOT EXISTS `coffee_shop`.`products` (
  `product_id` INT NOT NULL AUTO_INCREMENT,
  `name` VARCHAR(50) NOT NULL,
  `description` TEXT NOT NULL,
  `price` FLOAT NOT NULL,
  `size_floz` INT NOT NULL,
  PRIMARY KEY (`product_id`),
  UNIQUE INDEX `product_id_UNIQUE` (`product_id` ASC) VISIBLE)
ENGINE = InnoDB
AUTO_INCREMENT = 8
DEFAULT CHARACTER SET = utf8mb3;


-- -----------------------------------------------------
-- Table `coffee_shop`.`sales`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `coffee_shop`.`sales` ;

CREATE TABLE IF NOT EXISTS `coffee_shop`.`sales` (
  `sale_id` INT NOT NULL AUTO_INCREMENT,
  `date` DATE NULL DEFAULT NULL,
  `customer_id` INT NOT NULL,
  PRIMARY KEY (`sale_id`),
  UNIQUE INDEX `sale_id_UNIQUE` (`sale_id` ASC) VISIBLE,
  INDEX `customer_id_idx` (`customer_id` ASC) VISIBLE,
  CONSTRAINT `customer_id`
    FOREIGN KEY (`customer_id`)
    REFERENCES `coffee_shop`.`customers` (`customer_id`))
ENGINE = InnoDB
AUTO_INCREMENT = 11
DEFAULT CHARACTER SET = utf8mb3;


-- -----------------------------------------------------
-- Table `coffee_shop`.`line_items`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `coffee_shop`.`line_items` ;

CREATE TABLE IF NOT EXISTS `coffee_shop`.`line_items` (
  `line_items_id` INT NOT NULL AUTO_INCREMENT,
  `product_id` INT NOT NULL,
  `sale_id` INT NOT NULL,
  `quantity` INT NOT NULL,
  PRIMARY KEY (`line_items_id`),
  UNIQUE INDEX `sale_id_UNIQUE` (`line_items_id` ASC) VISIBLE,
  INDEX `product_id_idx` (`product_id` ASC) VISIBLE,
  INDEX `sale_id_idx` (`sale_id` ASC) VISIBLE,
  CONSTRAINT `product_id_line_items`
    FOREIGN KEY (`product_id`)
    REFERENCES `coffee_shop`.`products` (`product_id`),
  CONSTRAINT `sale_id`
    FOREIGN KEY (`sale_id`)
    REFERENCES `coffee_shop`.`sales` (`sale_id`))
ENGINE = InnoDB
AUTO_INCREMENT = 31
DEFAULT CHARACTER SET = utf8mb3;


-- -----------------------------------------------------
-- Table `coffee_shop`.`products_audit`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `coffee_shop`.`products_audit` ;

CREATE TABLE IF NOT EXISTS `coffee_shop`.`products_audit` (
  `name` VARCHAR(50) NOT NULL,
  `description` TEXT NOT NULL,
  `price` FLOAT NOT NULL,
  `size_floz` INT NOT NULL,
  `action_type` VARCHAR(50) NOT NULL,
  `action_time` DATETIME NOT NULL)
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8mb3;


-- -----------------------------------------------------
-- Table `coffee_shop`.`recipes`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `coffee_shop`.`recipes` ;

CREATE TABLE IF NOT EXISTS `coffee_shop`.`recipes` (
  `recipe_id` INT NOT NULL AUTO_INCREMENT,
  `product_id` INT NOT NULL,
  `ingredient_id` INT NOT NULL,
  `number_of_servings` INT NOT NULL,
  PRIMARY KEY (`recipe_id`),
  UNIQUE INDEX `recipe_id_UNIQUE` (`recipe_id` ASC) VISIBLE,
  INDEX `product_id_idx` (`product_id` ASC) VISIBLE,
  INDEX `ingredient_id_idx` (`ingredient_id` ASC) VISIBLE,
  CONSTRAINT `ingredient_id`
    FOREIGN KEY (`ingredient_id`)
    REFERENCES `coffee_shop`.`ingredients` (`ingredient_id`),
  CONSTRAINT `product_id_recipes`
    FOREIGN KEY (`product_id`)
    REFERENCES `coffee_shop`.`products` (`product_id`))
ENGINE = InnoDB
AUTO_INCREMENT = 13
DEFAULT CHARACTER SET = utf8mb3;

USE `coffee_shop` ;

-- -----------------------------------------------------
-- Placeholder table for view `coffee_shop`.`full_orders_v`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `coffee_shop`.`full_orders_v` (`Customer` INT, `Sale Date` INT, `Final Price` INT, `Number of Drinks Ordered` INT, `Total Fl Oz Ordered` INT);

-- -----------------------------------------------------
-- Placeholder table for view `coffee_shop`.`total_calories_v`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `coffee_shop`.`total_calories_v` (`Product` INT, `Drink Size` INT, `Total Calories` INT);

-- -----------------------------------------------------
-- procedure add_product
-- -----------------------------------------------------

USE `coffee_shop`;
DROP procedure IF EXISTS `coffee_shop`.`add_product`;

DELIMITER $$
USE `coffee_shop`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `add_product`(
	`new_name` VARCHAR(50),
    `new_description` TEXT,
    `new_price` FLOAT,
    `new_size_floz` INT
)
BEGIN
	DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
		SELECT 'Product addition unsuccesful due to SQL error.' AS 'Message';
    END;
    
    INSERT INTO products(`name`, `description`, `price`, `size_floz`)
	VALUES (`new_name`, `new_description`, `new_price`, `new_size_floz`);
    SELECT 'Product added successfully.' AS 'Message';
    
END$$

DELIMITER ;

-- -----------------------------------------------------
-- View `coffee_shop`.`full_orders_v`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `coffee_shop`.`full_orders_v`;
DROP VIEW IF EXISTS `coffee_shop`.`full_orders_v` ;
USE `coffee_shop`;
CREATE  OR REPLACE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `coffee_shop`.`full_orders_v` AS select `c`.`name` AS `Customer`,`s`.`date` AS `Sale Date`,concat('$',round(sum((`p`.`price` * `li`.`quantity`)),2)) AS `Final Price`,sum(`li`.`quantity`) AS `Number of Drinks Ordered`,sum((`p`.`size_floz` * `li`.`quantity`)) AS `Total Fl Oz Ordered` from (((`coffee_shop`.`sales` `s` join `coffee_shop`.`customers` `c` on((`c`.`customer_id` = `s`.`customer_id`))) join `coffee_shop`.`line_items` `li` on((`li`.`sale_id` = `s`.`sale_id`))) join `coffee_shop`.`products` `p` on((`p`.`product_id` = `li`.`product_id`))) group by `c`.`name`,`s`.`date`;

-- -----------------------------------------------------
-- View `coffee_shop`.`total_calories_v`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `coffee_shop`.`total_calories_v`;
DROP VIEW IF EXISTS `coffee_shop`.`total_calories_v` ;
USE `coffee_shop`;
CREATE  OR REPLACE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `coffee_shop`.`total_calories_v` AS select `p`.`name` AS `Product`,`p`.`size_floz` AS `Drink Size`,sum((`i`.`calories_per_serving` * `r`.`number_of_servings`)) AS `Total Calories` from ((`coffee_shop`.`products` `p` join `coffee_shop`.`recipes` `r` on((`p`.`product_id` = `r`.`product_id`))) join `coffee_shop`.`ingredients` `i` on((`i`.`ingredient_id` = `r`.`ingredient_id`))) group by `p`.`name`,`p`.`size_floz`;
USE `coffee_shop`;

DELIMITER $$

USE `coffee_shop`$$
DROP TRIGGER IF EXISTS `coffee_shop`.`products_after_delete` $$
USE `coffee_shop`$$
CREATE
DEFINER=`root`@`localhost`
TRIGGER `coffee_shop`.`products_after_delete`
AFTER DELETE ON `coffee_shop`.`products`
FOR EACH ROW
BEGIN
	INSERT INTO products_audit
    VALUES (OLD.`name`, OLD.`description`, OLD.`price`, OLD.`size_floz`, 'DELETED PRODUCT', NOW()); 
END$$


USE `coffee_shop`$$
DROP TRIGGER IF EXISTS `coffee_shop`.`products_after_insert` $$
USE `coffee_shop`$$
CREATE
DEFINER=`root`@`localhost`
TRIGGER `coffee_shop`.`products_after_insert`
AFTER INSERT ON `coffee_shop`.`products`
FOR EACH ROW
BEGIN
	INSERT INTO products_audit
    VALUES (NEW.`name`, NEW.`description`, NEW.`price`, NEW.`size_floz`, 'ADDED PRODUCT', NOW()); 
END$$


DELIMITER ;

SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;
