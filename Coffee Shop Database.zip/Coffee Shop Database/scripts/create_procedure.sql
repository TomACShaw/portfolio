-- Tom Shaw, IT 2351, 8/3/25
-- Creates a procedure to add a new product.
USE coffee_shop;
DELIMITER //
CREATE PROCEDURE add_product (
	`new_name` VARCHAR(50),
    `new_description` TEXT,
    `new_price` FLOAT,
    `new_size_floz` INT
)
BEGIN
	DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
		SELECT 'Product addition unsuccesful due to SQL error.' AS 'Message';
    END;
    INSERT INTO products(`name`, `description`, `price`, `size_floz`)
	VALUES (`new_name`, `new_description`, `new_price`, `new_size_floz`);
    SELECT 'Product added successfully.' AS 'Message';
END //
DELIMITER ;

CALL add_product('Pumpkin Berry Blast', 'A seasonal special latte. Try it before it''s gone!', 7.99, 12);