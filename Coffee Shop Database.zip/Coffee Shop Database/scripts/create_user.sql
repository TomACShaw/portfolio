-- Tom Shaw, IT 2351, 8/3/25
-- Creates a lead barista user who has barista privileges but can also
-- edit recipes.

CREATE USER 'Sojiro Sakura' IDENTIFIED BY 'password';
ALTER USER 'Sojiro Sakura'
	PASSWORD EXPIRE INTERVAL 30 DAY
    PASSWORD HISTORY 12;

GRANT barista TO 'Sojiro Sakura';
GRANT INSERT, DELETE, UPDATE ON recipes TO 'Sojiro Sakura';