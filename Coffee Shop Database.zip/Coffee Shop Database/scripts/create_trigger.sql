-- Tom Shaw, IT 2351, 8/3/25
-- Creates a trigger to track changes to the audit table.
DROP TABLE IF EXISTS products_audit;
CREATE TABLE products_audit (
	`name` VARCHAR(50) NOT NULL,
    `description` TEXT NOT NULL,
    `price` FLOAT NOT NULL,
    `size_floz` INT NOT NULL,
    action_type VARCHAR(50) NOT NULL,
    action_time DATETIME NOT NULL
);

USE coffee_shop;
DROP TRIGGER IF EXISTS products_after_insert;
DELIMITER //
CREATE TRIGGER products_after_insert
	AFTER INSERT ON products
	FOR EACH ROW
BEGIN
	INSERT INTO products_audit
    VALUES (NEW.`name`, NEW.`description`, NEW.`price`, NEW.`size_floz`, 'ADDED PRODUCT', NOW()); 
END//
DELIMITER ;

DROP TRIGGER IF EXISTS products_after_delete;
DELIMITER //
CREATE TRIGGER products_after_delete
	AFTER DELETE ON products
	FOR EACH ROW
BEGIN
	INSERT INTO products_audit
    VALUES (OLD.`name`, OLD.`description`, OLD.`price`, OLD.`size_floz`, 'DELETED PRODUCT', NOW()); 
END//
DELIMITER ;

CALL add_product('Red Eye', 'I hope you know what you''re doing...', 4.99, 10);
SELECT * FROM products_audit;