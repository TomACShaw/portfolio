-- Tom Shaw, IT 2351, 8/3/25
-- This script utilizes a series of queries to populate all tables in the coffee_shop database.

SELECT * FROM customers;
SELECT * FROM sales;
SELECT * FROM line_items;
SELECT * FROM products;
SELECT * FROM recipes;
SELECT * FROM suppliers;
SELECT * FROM ingredients;

SELECT i.`name`,
	s.`name`	
FROM ingredients i
	JOIN suppliers s ON i.supplier_id = s.supplier_id;


INSERT INTO customers (`name`, `phone`, `email`)
VALUES
	('Tom', '1234567890', 'tom@data.base'),
    ('Hannah', '4928375673', 'hmop@gmail.com'),
    ('Callie', '7177277347', 'c4lib3rt@yahoo.com'),
    ('Sir Nicholas de Mimsy-Porpington', '0000000001', 'nearlyheadless@ghostmail.net'),
    ('Andy', '9118675309', 'an@d.y')
;

INSERT INTO sales (`date`, `customer_id`)
VALUES
	('2025-08-03', 1),		-- Tom
    ('2025-08-03', 2),		-- Hannah
    ('2025-04-20', 5),		-- Andy
    ('2024-12-25', 3),		-- Callie
    ('1901-01-01', 4)		-- Nicholas
;

INSERT INTO line_items (`product_id`, `sale_id`, `quantity`)
VALUES
	(1, 1, 1), (2, 1, 1),						-- Tom's order
    (4, 2, 1),									-- Hannah's order
    (1, 3, 5), (4, 3, 4), (2, 3, 8),			-- Andy's order
    (2, 4, 1), (5, 4, 1),						-- Callie's order
    (2, 5, 6), (1, 5, 2)						-- Nicholas' order
;

INSERT INTO products (`name`, `description`, `price`, `size_floz`)
VALUES
	('Dark Chocolate Mocha', 'A chocolate-flavored coffee made with Valrhona cocoa nibs. A bittersweet blast of flavor.', 6.99, 16),
    ('Signature Cortado', 'A small espresso topped with steamed whole milk. Delicious espresso without the acidity.', 4.99, 4),
    ('Cappuccino', 'Espresso, milk, and foam. The perfect start to your morning.', 5.99, 8),
    ('Pistachio Chai Taste-splosion', 'My girlfriend''s favorite flavors in one beverage, extra hot.', 9.99, 24),
    ('Black Coffee', 'For the no-nonsense crowd. No, you''re not better than everyone else.', 2.99, 8)
;

INSERT INTO recipes (`product_id`, `ingredient_id`, `number_of_servings`)
VALUES
	(1, 1, 2), (1, 2, 3), (1, 3, 2),				-- Mocha recipe
    (2, 1, 2), (2, 2, .5),							-- Cortado recipe
    (3, 1, 2), (3, 2, 1.5),							-- Cappuccino recipe
    (4, 1, 4), (4, 2, 3), (4, 4, 4), (4, 5, 2),		-- Taste-splosion recipe
    (5, 6, 2)										-- Black Coffee recipe
;

INSERT INTO ingredients (`name`, `serving_size_floz`, `calories_per_serving`, `supplier_id`)
VALUES
	('Espresso', 1, 20, 1),
    ('Whole Milk', 4, 150, 2),
    ('Valrhona Cocoa', 1, 600, 3),
    ('Pistachio Syrup', 1, 100, 4),
    ('Chai Tea Concentrate', 2, 50, 1),
    ('Boring Beans', 4, 20, 1)
;

INSERT INTO suppliers (`name`, `address`, `email`)
VALUES
	('Captain Coffee', '1201 E 467 St, Cleveland, OH', 'order@captaincoffee.com'),
    ('Charli''s Milkers Creamery', '360 Brat Ave, Los Angeles, CA', 'milky@charli.xcx'),
    ('Chocoholics Anonymous', '1 Cocoa Way, Miami, FL', 'order@chocoholics.org'),
    ('Gal Fiery''s Flavorburg', '926 Main St, Meine Town, ME', 'notguy@flavor.blast'),
    ('Dunder Mifflin Paper Company','1725 Slough Ave, Ste 200, Scranton, PA', 'napkinsandmore@dundermifflin.michaelscott')
;