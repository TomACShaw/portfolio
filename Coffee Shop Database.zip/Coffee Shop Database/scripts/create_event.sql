-- Tom Shaw, IT 2351, 8/3/25
-- Creates an event to remove seasonal items from the products list each month.
USE coffee_shop;
DROP EVENT IF EXISTS clear_products_audit;
DELIMITER //
CREATE EVENT clear_products_audit
ON SCHEDULE
    EVERY 1 MONTH
    STARTS '2025-09-01 00:00:00'
DO BEGIN
    DELETE FROM products_audit
    WHERE `action_time` < NOW() - INTERVAL 1 MONTH;
END //
DELIMITER ;

SHOW EVENTS;