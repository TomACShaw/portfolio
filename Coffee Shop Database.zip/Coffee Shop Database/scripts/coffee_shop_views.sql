-- Tom Shaw, IT 2351, 8/3/25
-- Creates a view to shows the total number of calories in each drink
CREATE VIEW total_calories_v AS
SELECT p.`name` AS `Product`,
	p.size_floz AS `Drink Size`,
    SUM(calories_per_serving * number_of_servings) AS `Total Calories`
FROM products p
	JOIN recipes r ON p.product_id = r.product_id
	JOIN ingredients i ON i.ingredient_id = r.ingredient_id
GROUP BY p.`name`, p.`size_floz`;

SELECT * FROM total_calories_v;

-- Tom Shaw, IT 2351, 8/3/25
-- Creates a view to show the full order information including price,
-- number of drinks ordered, and total order size in floz.
CREATE VIEW full_orders_v AS
SELECT c.`name` AS `Customer`,
	s.`date` AS `Sale Date`,
	CONCAT('$', ROUND(SUM(p.price * quantity), 2)) AS `Final Price`,
    SUM(li.quantity) AS `Number of Drinks Ordered`,
    SUM(p.size_floz * quantity) AS `Total Fl Oz Ordered`
FROM sales s
	JOIN customers c ON c.customer_id = s.customer_id
    JOIN line_items li ON li.sale_id = s.sale_id
    JOIN products p ON p.product_id = li.product_id
GROUP BY c.`name`, s.`date`;

SELECT * FROM full_orders_v;