-- Tom Shaw, IT 2351, 8/3/25
-- Creates a barista role that can view products, ingredients, and recipe information.
-- Baristas cannot update tables or view sensitive accounting/customer/supplier information.

CREATE ROLE barista;
GRANT SELECT ON products TO barista;
GRANT SELECT ON ingredients TO barista;
GRANT SELECT ON recipes TO barista;